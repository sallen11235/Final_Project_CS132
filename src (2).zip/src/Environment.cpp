/*Joshua Lindquist & Sarah Allen
CS132 Winter 2022
Final Project: Simulation

Class main author:

Cpp file for Environment class*/

#include "Environment.h"

Environment::Environment() {}