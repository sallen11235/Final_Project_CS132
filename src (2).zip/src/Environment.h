/*Sarah Allen & Joshua Lindquist
CS132 Winter 2022
Final Project: Simulation

Class main author: 

Header class for environmental objects, such as buildings or plants. Will not move, sleep, etc.*/

#ifndef _ENVIRONMENT_H
#define _ENVIRONMENT_H

#include "Entity.h"

class Environment : public Entity {
public:
    //Constructor
    Environment();
private:

};

#endif