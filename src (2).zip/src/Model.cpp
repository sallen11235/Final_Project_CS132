/*Joshua Lindquist & Sarah Allen
CS132 Winter 2022
Final Project: Simulation

Class main author: 

*/

#include "Model.h"

using namespace std;

vector<vector<Entity*>>* Model::createNewVillage(int modelSize) {
    vector<vector<Entity*>>* EntityMap = new vector<vector<Entity*>>();
 
    // adding size inner vectors to the outer vector
    for(int i = 0; i < modelSize; i++) {
        vector<Entity*> row;
        // adding nullptr to every spot so it is the right size
        for(int j = 0; j < modelSize; j++) {
            row.push_back(nullptr);
        }
        EntityMap->push_back(row); 
    }
    return EntityMap;
}

Model::Model(int modelSize) {
    this->size = modelSize;
    map = createNewVillage(modelSize);
    

    vector<Entity*> animals{new Tiger(), new Hunter(), new Tree(), new Deer(), new Lumberjack, 
                            new Building};
    for(int i = 0; i < animals.size(); i++) {
        for(int j = 0; j < startEntNum; j++) {
            int x = rand() % modelSize;
            int y = rand() % modelSize;
            animals[i]->setPos(x,y);
            (*map)[x][y] = animals[i];
            //cout << "i = " << i << " type " << animals[i]->getType() << endl;
        }
    }
}

int Model::getSize() {
    return size;
}

//Entity* Model::typeTranslator(string type){}

void Model::mate(Entity* creature1, Entity* creature2) {
    string creature1Type = creature1->getType();
    string creature2Type = creature2->getType();

    //We need to add a new baby
    string type = creature1->getType();
    Entity* baby;
    if (type == "Deer") {
        baby = new Deer();
    } else if (type == "Hunter") {
        baby = new Hunter();
    } else if (type == "Lumberjack") {
        baby = new Lumberjack();
    } else if (type == "Tiger") {
        baby = new Tiger();
    } else if (type == "Tree") {
        baby = new Tree();
    } else {
        baby = nullptr;
    }

    addEntity(creature1->getY(), creature1->getX(), baby, oldMap);

}

Entity* Model::fight(Entity* creature1, Entity* creature2) {
    //get the types and the weapons for each creature
    string creature2Type2 = creature2->getType();
    Attack weapon1 = creature1->fight();
    
    string creature1Type2 = creature1->getType();
    Attack weapon2 = creature2->fight();

    Entity* winner = nullptr;

    if (weapon1 == weapon2) {
        throw string("Bug: Right now no two creatures have the same attack." 
                     " Creatures with the same type should not be fighting"); 
    } else if ((weapon2 == FORFEIT)|| (weapon1 == BITE && weapon2 == CHOP))
                 //|| (weapon1 == CHOP && weapon2 == BITE)
                /*|| (weapon1 == POUNCE && weapon2 == ROAR))  */{
        winner = creature1;
    } else if ((weapon1 == STAB && weapon2 == BITE) || (weapon1 == BITE && weapon2 == CHOP)) {
        winner = rand() % 2 == 0 ? creature1 : creature2;
    } else {
        winner = creature2;
    }

    return winner;
}

Entity* Model::getEntity(int row, int col) {
    return (*map)[row][col];
}

Entity* Model::modelNeighbor(int row, int col, Direction dir) {
    if (dir == NORTH) {
        if (row > 0) {
            cout << " dir = NORTH" << endl;
            return getEntity(row-1, col);
        } else {
            cout << " dir = null N" << endl;
            return nullptr;
        }
    } else if (dir == SOUTH) {
        if (row < size) {
            cout << " dir = SOUTH" << endl;
            return getEntity(row+1, col);
        } else {
            cout << " dir = null S" << endl;
            return nullptr;
        }
    } else if (dir == EAST) {
        if (col > 0) {
            cout << " dir = EAST" << endl;
            return getEntity(row, col-1);
        } else {
            cout << " dir = null E" << endl;
            return nullptr;
        }
    } else if (dir == WEST) {
        if (col < size) {
            cout << " dir = WEST" << endl;
            return getEntity(row, col+1);
        } else {
            cout << " dir = null W" << endl;
            return nullptr;
        }
    } else if (dir == CENTER) {
        throw string ("Error: Entity can not be its own neighbor.");
    }
    cout << " The code should not reach here :(" << endl;
    return nullptr;
}

void Model::addEntity(int row, int col, Entity* thing, vector<vector<Entity*>>* oldMap) {
    cout << thing->getType();
        Direction dir = thing->getMove();
        Entity* neighborE;
        string neighbor = "";
    if (dir != CENTER) { //Entity can't be its own neighbor
        neighborE = modelNeighbor(row, col, dir);
        if (neighborE != nullptr) {
            neighbor = neighborE->getType();
        }
        thing->setNeighbor(dir, neighbor);
    }
    int newRow = row;
    int newCol = col;

    //gets new row and new col for the rest of this function to work
    if(dir == WEST) {
        newRow = row - 1 < 0? map->size() - 1 : row - 1;
    } else if (dir == EAST) {
       newRow = (row + 1) % map->size();
    } else if (dir == SOUTH) {
        newCol = (col + 1) % map->size();
    } else if (dir == NORTH) {
        newCol = col - 1 < 0? map->size() - 1 : col - 1;
    }else {
        (*map)[row][col] = thing;
    }

    
    if(neighbor != "") {
        Entity* otherThing = (*oldMap)[newRow][newCol];
        //neighbor == thing->getType()? mate(thing,otherThing) : fight(thing, otherThing);
        
        if (neighbor == thing->getType() //If matching Entities or both humans
        || (neighbor == "Hunter" && thing->getType() == "Lumberjack") 
        || (neighbor == "Lumberjack" && thing->getType() == "Hunter")) {
            mate(thing, otherThing);
            thing->onMate();
            otherThing->onMate();
        } else {
            Entity* winner = fight(thing, otherThing);
            winner->onWin();
            //Winner takes the spot:
            (*map)[newRow][newCol] = winner;
        }
    } else {
        (*map)[newRow][newCol] = thing;
    }
}

void Model::update() {
    // create a new map 
    vector<vector<Entity*>>* newMap = createNewVillage(map->size());
    // creates a temporary pointer to point at the old state of the map
    // and points the member variable at the empty new map
    vector<vector<Entity*>>* oldMap = map;
    map = newMap;

    //
    for(int row = 0; row < map->size(); row++) {
        for(int col = 0; col < map->size(); col++) {
            Entity* thing = (*oldMap)[row][col];
           
            // when you come accross a Entity....
            if(thing != nullptr) {
               
                //Ensures each thing knows where it is
                thing->setPos(row, col);
                cout << "Thing pos: "<< thing->getX() << ", " << thing->getY() << endl;
                
                //Checks each direction for neighbors, would be good to make this a new function.
                for (Direction dir : {CENTER, NORTH, EAST, SOUTH, WEST}) {
                    Entity* neighbor;
                    int newRow = row;
                    int newCol = col;
                    if(dir == WEST) {
                        newRow = row - 1 < 0? map->size() - 1 : row - 1;
                    } else if (dir == EAST) {
                        newRow = (row + 1) % map->size();
                    } else if (dir == SOUTH) {
                        newCol = (col + 1) % map->size();
                    } else if (dir == NORTH) {
                        newCol = col - 1 < 0? map->size() - 1 : col - 1;
                    }else {
                        neighbor = (*oldMap)[row][col];
                    }
                    
                    neighbor = (*oldMap)[newRow][newCol]; 
                    
                    if (neighbor != nullptr) {
                        string neighborName = neighbor->getType();
                        thing->setNeighbor(dir, neighborName);
                    } else {
                        thing->setNeighbor(dir, "");
                    }
                }
                //Adds everything onto the map, this needs to be the last thing that happens here
                addEntity(row, col, thing, oldMap);
            }
        }
    }
}


void Model::placeEntity(int i, int j, Entity* e) {
    (*map)[i][j] = e;
}

ostream& operator<< (ostream& out, Entity* e) {
    if (e !=nullptr) {
        out << e->getType();
    } else {
        out << ".";
    }
    return out;
}