/*Sarah Allen & Joshua Lindquist
CS132 Winter 2022
Final Project: Simulation 

For our final project we decided to simulate a village. The villagers consist of hunters and
lumberjacks. The hunters will hunt deer for food, and no humans will mate until a food threshold 
is met. The lumberjacks will cut down trees, and once enough wood is gathered they will build a
house. There are also tigers roaming about, which only hunters can stand a chance against.

As for this main() file, it simply creates the GUI. 
Feel free to change the model size and the square size :)*/

#include "Gui.h"

int main() {
    //Gui (size in pixels of model, size in pixels of grid's squares)
    new Gui(1000, 20);
    return 0;
}