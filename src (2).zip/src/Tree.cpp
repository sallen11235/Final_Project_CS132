/*Joshua Lindquist & Sarah Allen
CS132 Winter 2022
Final Project: Simulation

Class main author:

Cpp file for the Tree class*/

#include "Tree.h"


Tree::Tree() {}

string Tree::getType() {
    return "Tree";
}

string Tree::toString() {
    //if (boolVar) {      IF we want to implement tree diversity we will need to construct trees with a randomized bool!!
    return "\xF0\x9F\x8C\xB2";
    //} else {
        //return "\xF0\x9F\x8C\xB3";
    //}
}

string Tree::getColor() {
    return "yellow";
}