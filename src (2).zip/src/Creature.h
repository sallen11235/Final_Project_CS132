/*Sarah Allen & Joshua Lindquist
CS132 Winter 2022
Final Project: Simulation

Class main author:

Header for Creature class, defining human and animal behavior. */

#ifndef _Creature_H
#define _Creature_H

#include "Entity.h"
//                                     UUUUH maybe combine with Villager into one class? Mammals or ambulators or smth

/*JL: Ya we should either move some of this into entity and not use it for trees and buildings or we should make a parent 
class that takes care of most of this*/

class Creature : public Entity {
public:

    Creature();
    //Returns true until Creature loses a fight, destructing the Creature
    virtual bool isAlive();

    //Returns true until onSleep() sets to false
    virtual bool isAwake();

    //Sets isAlive() to return false
    virtual void onLose();

    //                                                           NGL idk how to describe these
    virtual void onMate();
    virtual void onMateEnd();
    virtual void onSleep();
    virtual void onWakeUp();
    virtual void onWin();

    

    //Default attack of FORFEIT
    virtual Attack fight(string);


private:
bool alive;
bool awake;
int woodCount;
int foodCount;
};

#endif